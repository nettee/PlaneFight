#ifndef PLANE_H_
#define PLANE_H_

#include "buffer.h"

extern Buffer buffer;

const int max_life = 6;

class Plane {
private:
	int x, y;
	const char *shape;
	const int width;
	const int h_step, v_step;

	int life;

public:
	Plane();
	~Plane();

public:
	bool isDead() { return life <= 0; }
	void print_life();

public:
	void show();
	void hide();

	void move_left();
	void move_right();
	void move_up();
	void move_down();

	void fire();

	void update();
	bool hit_with_enemy();
};

#endif /* PLANE_H_ */
