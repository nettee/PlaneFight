#include "defs.h"

Screen screen = {31, 50};


