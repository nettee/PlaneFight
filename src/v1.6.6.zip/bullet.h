#ifndef BULLET_H_
#define BULLET_H_

#include "defs.h"
#include "flyable.h"

class Bullet : public Flyable {
private:
	const int h_step, v_step;

public:
	Bullet(int x, int y);

	void forward() {
		move_up();
	}

private:
	void move_up();

public:
	// check if the bullet is in given area
	bool in(Area area) {
		return area.contains(x, y);
	}
};

#endif /* BULLET_H_ */
