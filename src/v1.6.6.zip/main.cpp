#include <stdio.h>
#include <stdlib.h>

#include <windows.h>
#include <conio.h>

#include "defs.h"
#include "buffer.h"

void init_console();
void do_welcome();
void play_game();

Buffer buffer;

int main()
{
	init_console();

	while (true) {
		do_welcome();

		while (!kbhit());
		char c = getch();

		if (c == 'q') {
			exit(0);
		} else {
			play_game();
		}
	}

    return 0;
}


void do_welcome()
{
	buffer.clear();
	buffer.draw_string("PLANE FIGHT", 7);
	buffer.draw_string("version 1.6.6", 9);
	buffer.draw_string("Help poor children in Uganda!", 15);
	buffer.display();
}

/* version history:
 * 1.6.0 can collide with enemy
 * 1.6.1 enemy will destroy (totally disappear) after collision
 * 1.6.2 heart decrease after collision
 * 1.6.3 add Area type
 * 1.6.4 use Area for bullet collision judgment
 * 1.6.5 use overlaps() instead of in()
 * 1.6.6 improvement and stability
 *
 */
