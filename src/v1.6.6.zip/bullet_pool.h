#ifndef BULLET_POOL_H_
#define BULLET_POOL_H_

#include <list>

#include "defs.h"
#include "bullet.h"

class BulletPool {
private:
	std::list<Bullet> bullets;
	typedef std::list<Bullet>::iterator list_iter;

public:
	void add(int x, int y);
	void forward();

public:
	bool check_collision(Area area);
};

#endif /* BULLET_POOL_H_ */
