#include "enemy.h"

#include <cstring>
#include <cassert>

#include "defs.h"
#include "buffer.h"
#include "bullet_pool.h"

enemy_info enemy_list[NR_ENEMY] = {
		{"=.=", 3, 4, 1},
		{"(-_-)", 5, 9, 2},
		{"=-[o_o]-=", 9, 21, 5},
};

Enemy::Enemy(int x, int y, int type): Flyable(x, y),
		h_step(1), v_step(1) {
	enemy_info ei = enemy_list[type];
	width = ei.width;
	shape = new char[width+1];
	strcpy(shape, ei.shape);
	life = ei.life;
	value = ei.value;
}

void Enemy::move_down() {
	assert(alive);
	hide();
	y = y + v_step;
	if (y < screen.height) {
		show();
	} else {
		alive = false;
	}
}

bool Enemy::hit_with_bullet() {
	extern BulletPool bpool;
	Area area(x, y, x+width-1, y);
	return bpool.check_collision(area);
}

void Enemy::destroy() {
	extern unsigned int score;
	score += this->value;
	hide();
}
