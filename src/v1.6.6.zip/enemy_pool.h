#ifndef ENEMY_POOL_H_
#define ENEMY_POOL_H_

#include <list>

#include "defs.h"
#include "enemy.h"

class EnemyPool {
private:
	std::list<Enemy> enemies;
	typedef std::list<Enemy>::iterator list_iter;

public:
	void add(int x, int y, int type);
	void forward();
	void update();
	bool check_collision(Area area);
};

#endif /* ENEMY_POOL_H_ */
