#include "enemy_pool.h"

using namespace std;

void EnemyPool::add(int x, int y, int type) {
	enemies.push_back(Enemy(x, y, type));
}

void EnemyPool::forward() {
	for (list_iter it = enemies.begin(); it != enemies.end(); ++it) {
		if (it->isAlive()) {
			it->forward();
		} else {
			// remove dead enemies
			it = enemies.erase(it);
		}
	}
}

void EnemyPool::update() {
	for (list_iter it = enemies.begin(); it != enemies.end(); ++it) {
		if (it->hit_with_bullet()) {
			if (it->life > 0) {
				it->life--;
			} else {
				it->destroy();
				it = enemies.erase(it);
			}
		}
	}
}

bool EnemyPool::check_collision(Area area) {
	bool flag = false;
	for (list_iter it = enemies.begin(); it != enemies.end(); ++it) {
		if (it->overlaps(area)) {
			it->destroy();
			it = enemies.erase(it);
			flag = true;
		}
	}
	return flag;
}
