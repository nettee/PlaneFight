#include "plane.h"

#include <cassert>
#include <cstring>

#include "defs.h"
#include "bullet_pool.h"
#include "enemy_pool.h"

extern BulletPool bpool;

Plane::Plane(): shape("^_^"), width(strlen(shape)), h_step(2), v_step(1) {
	x = screen.width / 2;
	y = screen.height * 4 / 5;
	life = 3;
}

Plane::~Plane() {

}

void Plane::print_life() {
	for (int i = 0; i < max_life; i++) {
		if (i < life) {
			buffer.draw_character('\3', screen.width-1 - i, 0);
		} else {
			buffer.draw_character(' ', screen.width-1 - i, 0);
		}

	}
}

void Plane::show() {
	buffer.draw_string(shape, x, y);
}

void Plane::hide() {
	char *blanks = new char[width+1];
	for (int i = 0; i < width; i++) {
		blanks[i] = ' ';
	}
	blanks[width] = '\0';
	buffer.draw_string(blanks, x, y);
}

void Plane::move_left() {
	hide();
	if (x - h_step >= 0) {
		x = x - h_step;
	}
	show();
}

void Plane::move_right() {
	hide();
	if ((x + width - 1) + h_step <= screen.width - 1) {
		x = x + h_step;
	}
	show();
}

void Plane::move_up() {
	hide();
	// WORKAROUND
	if (y - v_step >= 1) {
		y = y - v_step;
	}
	show();
}

void Plane::move_down() {
	hide();
	if (y + v_step <= screen.height - 1) {
		y = y + v_step;
	}
	show();
}

void Plane::fire() {
	bpool.add(x+1, y-1);
}

void Plane::update() {
	if (hit_with_enemy()) {
		life--;
	}
}

bool Plane::hit_with_enemy() {
	extern EnemyPool epool;
	Area area(x, y, x+width-1, y);
	return epool.check_collision(area);
}
