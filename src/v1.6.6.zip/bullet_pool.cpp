#include "bullet_pool.h"

using namespace std;

void BulletPool::add(int x, int y) {
	bullets.push_back(Bullet(x, y));
}

void BulletPool::forward() {
	for (list_iter it = bullets.begin(); it != bullets.end(); ++it) {
		if (it->isAlive()) {
			it->forward();
		} else {
			// remove inactive bullets
			it = bullets.erase(it);
		}
	}
}

/* Check if any bullet collides with the object who occupies the area
 * if there exists, erase the bullet, and return true
 */
bool BulletPool::check_collision(Area area) {
	for (list_iter it = bullets.begin(); it != bullets.end(); ++it) {
		if (it->overlaps(area)) {
			bullets.erase(it);
			return true;
		}
	}
	return false;
}
