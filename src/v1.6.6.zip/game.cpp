#include <cstdio>
#include <cstdlib>

#include <windows.h>
#include <conio.h>

#include "defs.h"
#include "buffer.h"
#include "plane.h"
#include "bullet_pool.h"
#include "enemy.h"
#include "enemy_pool.h"

bool tick();
int time();

extern Buffer buffer;

struct Key {
	char left, right, up, down;
} key = {'a', 'd', 'w', 's'};

unsigned int score;

Plane plane;
BulletPool bpool;
EnemyPool epool;

void init_game()
{
	buffer.clear();
	plane.show();
	buffer.display();
	score = 0;
}

void put_score() {
	char s[20];
	sprintf(s, "Score: %d", score);
	buffer.draw_string(s, 0, 0);
}

void put_plane_life() {
	plane.print_life();
}

void generate_enemy() {
	int type = rand() % NR_ENEMY;
	enemy_info ei = enemy_list[type];
	int x = rand() % (screen.width - ei.width);
	epool.add(x, 0, type);
}

void play_game()
{
	init_game();

	while (true) {

		// watch keyboard hit
		if (kbhit()) {
			char k = getch();
			if (k == key.left) {
				plane.move_left();
			} else if (k == key.right) {
				plane.move_right();
			} else if (k == key.up) {
				plane.move_up();
			} else if (k == key.down) {
				plane.move_down();
			}
		}


		if (tick()) {

			// bullets go forward
			bpool.forward();
			epool.update();

			// enemy go forward
			if (time() % 2 == 0) {
				epool.forward();
				epool.update();
			}

			plane.update();

			if (time() % 3 == 0) {
				generate_enemy();
			}

			plane.fire();
		}


		plane.show();  // ensure the plane is always visual
		put_score();
		put_plane_life();
		buffer.display();

	}
}
