#ifndef FLYABLE_H_
#define FLYABLE_H_

#include <cstdio>

#include "defs.h"
#include "buffer.h"

extern Buffer buffer;

class Flyable {
protected:
	int x, y;
	bool alive;
	char *shape;
	int width;

public:
	// must be initialized by coordinates
	Flyable(int x, int y): shape(NULL), width(0) {
		this->x = x;
		this->y = y;
		alive = true;
	}

public:
	bool overlaps(Area area) {
		for (int i = 0; i < width; i++) {
			if (area.contains(x + i, y)) {
				return true;
			}
		}
		return false;
	}

protected:
	void hide() {
		char *blanks = new char[width+1];
		for (int i = 0; i < width; i++) {
			blanks[i] = ' ';
		}
		blanks[width] = '\0';
		buffer.draw_string(blanks, x, y);
	}

	void show() {
		buffer.draw_string(shape, x, y);
	}

public:
	bool isAlive() {
		return alive;
	}

	void forward();
};

#endif /* FLYABLE_H_ */
