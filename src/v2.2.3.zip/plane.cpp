#include "plane.h"

#include <cassert>
#include <cstring>

#include "defs.h"
#include "pool.h"

Plane::Plane(): shape("^_^"), width(strlen(shape)), h_step(2), v_step(1) {
	init();
}

void Plane::init() {
	x = scr_width / 2;
	y = scr_height * 4 / 5;

	life = 3;
	fire_double = 0;
	fire_enhance = 0;
	score_double = 0;
}

Area Plane::area() {
	return Area(x, y, x+width-1, y);
}

void Plane::show() {
	buffer.draw_string(shape, x, y);
}

void Plane::hide() {
	char *blanks = new char[width+1];
	for (int i = 0; i < width; i++) {
		blanks[i] = ' ';
	}
	blanks[width] = '\0';
	buffer.draw_string(blanks, x, y);
}

void Plane::move_left() {
	hide();
	if (x - h_step >= 0) {
		x = x - h_step;
	}
	show();
}

void Plane::move_right() {
	hide();
	if ((x + width - 1) + h_step <= scr_width - 1) {
		x = x + h_step;
	}
	show();
}

void Plane::move_up() {
	hide();
	if (y - v_step >= 1) {
		y = y - v_step;
	}
	show();
}

void Plane::move_down() {
	hide();
	if (y + v_step <= scr_height - 1) {
		y = y + v_step;
	}
	show();
}

void Plane::fire() {
	int type = (fire_enhance > 0) ? bullet_enhanced : bullet_common;
	if (fire_double > 0) {
		bpool.add(x, y-1, type);
		bpool.add(x+2, y-1, type);
	} else {
		bpool.add(x+1, y-1, type);
	}
}

void Plane::update() {
	if (fire_double > 0) fire_double--;
	if (fire_enhance > 0) fire_enhance--;
	if (score_double > 0) score_double--;
}
