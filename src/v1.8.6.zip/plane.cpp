#include "plane.h"

#include <cassert>
#include <cstring>

#include "defs.h"
#include "pool.h"

extern BulletPool bpool;

Plane::Plane(): shape("^_^"), width(strlen(shape)), h_step(2), v_step(1) {
	init();
}

void Plane::init() {
	x = scr_width / 2;
	y = scr_height * 4 / 5;
	life = 3;
}

void Plane::print_life() {
	for (int i = 0; i < max_life; i++) {
		if (i < life) {
			buffer.draw_character('\3', scr_width-1 - i, 0);
		} else {
			buffer.draw_character(' ', scr_width-1 - i, 0);
		}

	}
}

void Plane::show() {
	buffer.draw_string(shape, x, y);
}

void Plane::hide() {
	char *blanks = new char[width+1];
	for (int i = 0; i < width; i++) {
		blanks[i] = ' ';
	}
	blanks[width] = '\0';
	buffer.draw_string(blanks, x, y);
}

void Plane::move_left() {
	hide();
	if (x - h_step >= 0) {
		x = x - h_step;
	}
	show();
}

void Plane::move_right() {
	hide();
	if ((x + width - 1) + h_step <= scr_width - 1) {
		x = x + h_step;
	}
	show();
}

void Plane::move_up() {
	hide();
	// WORKAROUND
	if (y - v_step >= 1) {
		y = y - v_step;
	}
	show();
}

void Plane::move_down() {
	hide();
	if (y + v_step <= scr_height - 1) {
		y = y + v_step;
	}
	show();
}

void Plane::fire() {
	bpool.add(x+1, y-1);
}

void Plane::update() {
	if (hit_supply()) {
		increase_life();
	}

	if (hit_enemy()) {
		decrease_life();
	}
}

bool Plane::hit_supply() {
	extern SupplyPool spool;
	Area area(x, y, x+width-1, y);
	return spool.check_collision(area);
}

bool Plane::hit_enemy() {
	extern EnemyPool epool;
	Area area(x, y, x+width-1, y);
	return epool.check_collision(area);
}
