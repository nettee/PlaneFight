#include "enemy.h"
#include "pool.h"

#include <cstring>
#include <cassert>

#include "defs.h"
#include "buffer.h"

enemy_info enemy_list[NR_ENEMY] = {
		{"=.=", 3, 4, 1},
		{"(-_-)", 5, 9, 2},
		{"=-[o_o]-=", 9, 21, 5},
};

Enemy::Enemy(int x, int y, int type): Flyable(x, y),
		h_step(1), v_step(1) {
	enemy_info ei = enemy_list[type];
	width = ei.width;
	shape = new char[width+1];
	strcpy(shape, ei.shape);
	life = ei.life;
	value = ei.value;
}

void Enemy::move_down() {
	assert(alive);
	hide();
	y = y + v_step;
	if (y < scr_height) {
		show();
	} else {
		alive = false;
	}
}

bool Enemy::hit_with_bullet() {
	extern BulletPool bpool;
	Area area(x, y, x+width-1, y);
	return bpool.check_collision(area);
}

void Enemy::destroy() {
	extern unsigned int score;
	score += this->value;
	hide();
}

void EnemyPool::clear() {
	enemies.clear();
}

void EnemyPool::add(int x, int y, int type) {
	enemies.push_back(Enemy(x, y, type));
}

void EnemyPool::forward() {
	for (list_iter it = enemies.begin(); it != enemies.end(); ++it) {
		if (it->isAlive()) {
			it->forward();
		} else {
			// remove dead enemies
			it = enemies.erase(it);
		}
	}
}

void EnemyPool::update() {
	for (list_iter it = enemies.begin(); it != enemies.end(); ++it) {
		if (it->hit_with_bullet()) {
			if (it->life > 0) {
				it->life--;
				it->redraw();  // ensure enemy is wholly displayed
			} else {
				it->destroy();
				it = enemies.erase(it);
			}
		}
	}
}

bool EnemyPool::check_collision(Area area) {
	bool result = false;
	for (list_iter it = enemies.begin(); it != enemies.end(); ++it) {
		if (it->overlaps(area)) {
			it->destroy();
			it = enemies.erase(it);
			result = true;
		}
	}
	return result;
}
