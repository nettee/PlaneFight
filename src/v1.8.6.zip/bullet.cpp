#include "bullet.h"
#include "pool.h"

#include <cstring>
#include <cassert>

#include "buffer.h"

const char *bullet_shape = "'";

Bullet::Bullet(int x, int y):
	Flyable(x, y),
	h_step(1), v_step(1) {
	width = strlen(bullet_shape);
	shape = new char[width+1];
	strcpy(shape, bullet_shape);
}

void Bullet::move_up() {
	assert(alive);
	hide();
	y = y - v_step;
	if (y >= 0) {
		show();
	} else {
		alive = false;
	}
}

void Bullet::destroy() {
	hide();
}

void BulletPool::clear() {
	bullets.clear();
}

void BulletPool::add(int x, int y) {
	bullets.push_back(Bullet(x, y));
}

void BulletPool::forward() {
	for (list_iter it = bullets.begin(); it != bullets.end(); ++it) {
		if (it->isAlive()) {
			it->forward();
		} else {
			// remove inactive bullets
			it = bullets.erase(it);
		}
	}
}

/* Check if any bullet collides with the object who occupies the area
 * if there exists, erase the bullet, and return true
 */
bool BulletPool::check_collision(Area area) {
	bool result = false;
	for (list_iter it = bullets.begin(); it != bullets.end(); ++it) {
		if (it->overlaps(area)) {
			it->destroy();
			it = bullets.erase(it);
			result = true;
		}
	}
	return result;
}
