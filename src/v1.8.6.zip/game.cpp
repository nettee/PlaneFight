#include <cstdio>
#include <cstdlib>
#include <time.h>
#include <windows.h>
#include <conio.h>

#include "defs.h"
#include "buffer.h"
#include "plane.h"
#include "enemy.h"
#include "supply.h"
#include "pool.h"

bool tick();
int second();

extern Buffer buffer;

struct Key {
	char left, right, up, down;
} key = {'a', 'd', 'w', 's'};

unsigned int score;

Plane plane;
BulletPool bpool;
EnemyPool epool;
SupplyPool spool;

void init_game()
{
	plane.init();
	bpool.clear();
	epool.clear();
	spool.clear();

	srand(time(NULL));

	buffer.clear();
	plane.show();
	buffer.display();
	score = 0;
}

void put_score() {
	char s[20];
	sprintf(s, "Score: %d", score);
	buffer.draw_string(s, 0, 0);
}

void put_plane_life() {
	plane.print_life();
}

void generate_enemy() {
	int type = rand() % NR_ENEMY;
	enemy_info ei = enemy_list[type];
	int x = rand() % (scr_width - ei.width + 1);
	epool.add(x, 0, type);
}

bool generate_supply() {
	int type = SP_APPLE;
	supply_info si = supply_list[type];
	int x = rand() % (scr_width - si.width + 1);
	spool.add(x, 0, type);
	return true;
}

void play_game()
{
	init_game();

	while (true) {

		// watch keyboard hit
		if (kbhit()) {
			char k = getch();
			if (k == key.left) {
				plane.move_left();
			} else if (k == key.right) {
				plane.move_right();
			} else if (k == key.up) {
				plane.move_up();
			} else if (k == key.down) {
				plane.move_down();
			}
		}


		if (tick()) {

			// bullets go forward
			bpool.forward();
			epool.update();

			// enemy go forward
			if (second() % 2 == 0) {
				spool.forward();
				epool.forward();
				epool.update();
			}

			plane.update();

			if (plane.isDead()) {
				Sleep(200);
				return;
			}

			if (second() % 43 == 0) {
				generate_supply();
			}
			else if (second() % 3 == 0) {
				generate_enemy();
			}

			plane.fire();
		}


		plane.show();  // ensure the plane is always visual
		put_score();
		put_plane_life();
		buffer.display();

	}
}
