#include "buffer.h"

#include <cstdio>
#include <cassert>
#include <cstring>
#include <windows.h>

#include "defs.h"

HANDLE writeHandle;

void init_console()
{
	writeHandle = GetStdHandle(STD_OUTPUT_HANDLE);

	SetConsoleTitle(TEXT("Plane Fight"));

	SMALL_RECT windowSize = {0, 0, (short)(scr_width-1), (short)(scr_height-1)};
	SetConsoleWindowInfo(writeHandle, TRUE, &windowSize);

	COORD bufferSize = {scr_width, (short)(scr_height)};
	SetConsoleScreenBufferSize(writeHandle, bufferSize);
}


Buffer::Buffer() {
	a = new char[scr_height * scr_width];
	clear();
}

Buffer::~Buffer() {
	delete[] a;
}

void Buffer::clear() {
	for (int y = 0; y < scr_height; y++) {
		for (int x = 0; x < scr_width; x++) {
			a[flat(x, y)] = ' ';
		}
	}
}

void Buffer::draw_character(char ch, int x, int y) {
	assert(x >= 0 && x < scr_width);
	assert(y >= 0 && y < scr_height);
	a[flat(x, y)] = ch;
}

void Buffer::draw_string(const char *str, int x, int y) {
	assert(x >= 0 && x < scr_width);
	assert(y >= 0 && y < scr_height);
	for (int i = 0; str[i] != '\0'; i++) {
		draw_character(str[i], x + i, y);
	}
}

void Buffer::draw_string(const char *str, int y) {
	int x = (scr_width - strlen(str)) / 2;
	draw_string(str, x, y);
}

void Buffer::display() {
	CHAR_INFO chars[scr_width * scr_height];
	for (short y = 0; y < scr_height; y++) {
		for (short x = 0; x < scr_width; x++) {
			chars[flat(x, y)].Char.AsciiChar = a[flat(x, y)];
			chars[flat(x, y)].Attributes =  FOREGROUND_RED | FOREGROUND_BLUE | FOREGROUND_GREEN;
		}
	}
	COORD charBufSize = {scr_width, scr_height};
	COORD charPosition = {0, 0};
	SMALL_RECT writeArea = {0, 0, (short)(scr_width-1), (short)(scr_height-1)};
	WriteConsoleOutput(writeHandle, chars, charBufSize, charPosition, &writeArea);
}


