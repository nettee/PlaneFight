#ifndef SUPPLY_H_
#define SUPPLY_H_

#include "flyable.h"

struct supply_info {
	const char *shape;
	const int width;
};

extern supply_info supply_list[];

#define NR_SUPPLY 1

enum supply_type {
		SP_APPLE,
};

class Supply : public Flyable {
private:
	const int h_step, v_step;

public:
	Supply(int x, int y, int type);

	void forward() {
		move_down();
	}

private:
	void move_down();

public:
	void destroy();

};

#endif /* SUPPLY_H_ */
