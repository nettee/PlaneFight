#include <stdio.h>
#include <stdlib.h>

#include <windows.h>
#include <conio.h>

#include "defs.h"
#include "buffer.h"

void init_console();
void do_welcome();
void play_game();
void do_encourage();

Buffer buffer;

void do_welcome()
{
	buffer.clear();
	buffer.draw_string("PLANE FIGHT", 7);
	buffer.draw_string("version 1.8.6", 9);
	buffer.draw_string("Help poor children in Uganda!", 15);
	buffer.display();
}

void do_encourage() {
	buffer.clear();
	buffer.draw_string("GAME OVER!", 7);
	buffer.display();
}

int main()
{
	init_console();
	do_welcome();

	while (true) {

		while (!kbhit());
		char c = getch();

		if (c == 'q') {
			exit(0);
		} else {
			play_game();
		}

		do_encourage();
	}

    return 0;
}


/* version history:
 *
 * 1.8.0 design game status // for game over
 * 1.8.1 improve method of adding heart
 * 1.8.2 now plane can die
 * 1.8.3 add Plane::init()
 * 1.8.4 add Pool::clear()
 * 1.8.5 now can game over
 * 1.8.6 use srand() to make better random number
 *
 *
 * 1.7.0 add supply apple
 * 1.7.1 set apple shape
 * 1.7.2 set frequency of apple
 * 1.7.3 apple can be eaten by plane
 * 1.7.4 eating apple can add heart
 * 1.7.5 fix bug of redrawing enemy
 * 1.7.6 merge pool header files
 * 1.7.7 merge bullet, enemy, supply files with pool
 *
 * 1.6.0 can collide with enemy
 * 1.6.1 enemy will destroy (totally disappear) after collision
 * 1.6.2 heart decrease after collision
 * 1.6.3 add Area type
 * 1.6.4 use Area for bullet collision judgment
 * 1.6.5 use overlaps() instead of in()
 * 1.6.6 improvement and stability
 * 1.6.7 abandon in()
 *
 */
