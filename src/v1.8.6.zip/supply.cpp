#include "supply.h"
#include "pool.h"

#include <cstring>
#include <cassert>

#include "plane.h"

supply_info supply_list[NR_SUPPLY] = {
		{"\3", 1},
};

Supply::Supply(int x, int y, int type): Flyable(x, y),
		h_step(1), v_step(1) {
	supply_info si = supply_list[type];
	width = si.width;
	shape = new char[width+1];
	strcpy(shape, si.shape);
}

void Supply::move_down() {
	assert(alive);
	hide();
	y = y + v_step;
	if (y < scr_height) {
		show();
	} else {
		alive = false;
	}
}

void Supply::destroy() {
	hide();
}

void SupplyPool::clear() {
	supplies.clear();
}

void SupplyPool::add(int x, int y, int type) {
	supplies.push_back(Supply(x, y, type));
}

void SupplyPool::forward() {
	for (list_iter it = supplies.begin(); it != supplies.end(); ++it) {
		if (it->isAlive()) {
			it->forward();
		} else {
			// remove inactive supplies
			it = supplies.erase(it);
		}
	}
}

bool SupplyPool::check_collision(Area area) {
	bool result = false;
	for (list_iter it = supplies.begin(); it != supplies.end(); ++it) {
		if (it->overlaps(area)) {
			it->destroy();
			it = supplies.erase(it);
			result = true;
		}
	}
	return result;
}
