#ifndef BULLET_H_
#define BULLET_H_

#include "flyable.h"

class Bullet : public Flyable {
private:
	const int h_step, v_step;

public:
	Bullet(int x, int y);

	void forward() {
		move_up();
	}

private:
	void move_up();

public:
	// check if the bullet is in given area
	bool in(int x1, int y1, int x2, int y2) {
		return (x >= x1 && x <= x2)
				&& (y >= y1 && y <= y2);
	}
};

#endif /* BULLET_H_ */
