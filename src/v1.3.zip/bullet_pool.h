#ifndef BULLET_POOL_H_
#define BULLET_POOL_H_

#include <list>

#include "bullet.h"

class BulletPool {
private:
	std::list<Bullet> bullets;

public:
	void add(int x, int y);
	void forward();

public:
	bool check_collision(int x1, int y1, int x2, int y2);
};

#endif /* BULLET_POOL_H_ */
