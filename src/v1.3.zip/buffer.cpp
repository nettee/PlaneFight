#include "buffer.h"

#include <cstdio>
#include <cassert>
#include <cstring>
#include <windows.h>

#include "defs.h"

HANDLE writeHandle;

void init_console()
{
	writeHandle = GetStdHandle(STD_OUTPUT_HANDLE);

	SetConsoleTitle(TEXT("Plane Fight"));

	SMALL_RECT windowSize = {0, 0, (short)(screen.width-1), (short)(screen.height+1-1)};
	SetConsoleWindowInfo(writeHandle, TRUE, &windowSize);

	COORD bufferSize = {screen.width, (short)(screen.height+1)};
	SetConsoleScreenBufferSize(writeHandle, bufferSize);
}


Buffer::Buffer() {
	a = new char[screen.height * screen.width];
	clear();
}

Buffer::~Buffer() {
	delete[] a;
}

void Buffer::clear() {
	for (int y = 0; y < screen.height; y++) {
		for (int x = 0; x < screen.width; x++) {
			a[flat(x, y)] = ' ';
		}
//		a[flat(0, y)] = '0' + (y % 10);
	}
}

void Buffer::draw_character(char ch, int x, int y) {
	assert(x >= 0 && x < screen.width);
	assert(y >= 0 && y < screen.height);
	a[flat(x, y)] = ch;
}

void Buffer::draw_string(const char *str, int x, int y) {
	assert(x >= 0 && x < screen.width);
	assert(y >= 0 && y < screen.height);
	for (int i = 0; str[i] != '\0'; i++) {
		draw_character(str[i], x + i, y);
	}
}

void Buffer::draw_string(const char *str, int y) {
	int x = (screen.width - strlen(str)) / 2;
	draw_string(str, x, y);
}

void Buffer::display() {
	CHAR_INFO chars[screen.width * screen.height];
	for (short y = 0; y < screen.height; y++) {
		for (short x = 0; x < screen.width; x++) {
			chars[flat(x, y)].Char.AsciiChar = a[flat(x, y)];
			chars[flat(x, y)].Attributes =  FOREGROUND_RED | FOREGROUND_BLUE | FOREGROUND_GREEN;
		}
	}
	COORD charBufSize = {screen.width, screen.height};
	COORD charPosition = {0, 0};
	SMALL_RECT writeArea = {0, 0, (short)(screen.width-1), (short)(screen.height-1)};
	WriteConsoleOutput(writeHandle, chars, charBufSize, charPosition, &writeArea);
}


