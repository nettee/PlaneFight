#include "bullet_pool.h"

using namespace std;

void BulletPool::add(int x, int y) {
	bullets.push_back(Bullet(x, y));
}

void BulletPool::forward() {
	for (list<Bullet>::iterator it = bullets.begin();
			it != bullets.end(); ++it) {
		if (it->isAlive()) {
			it->forward();
		} else {
			// remove inactive bullets
			it = bullets.erase(it);
		}
	}
}

/* Check if any bullet collides with the object,
 * whose occupies area between (x1, y1) and (x2, y2)
 * if there exists, erase the bullet, and return true
 */
bool BulletPool::check_collision(int x1, int y1, int x2, int y2) {
	for (list<Bullet>::iterator it = bullets.begin();
			it != bullets.end(); ++it) {
		if (it->in(x1, y1, x2, y2)) {
			bullets.erase(it);
			return true;
		}
	}
	return false;
}
