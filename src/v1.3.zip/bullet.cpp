#include "bullet.h"

#include <cstring>
#include <cassert>

#include "buffer.h"

const char *bullet_shape = "'";

Bullet::Bullet(int x, int y):
	Flyable(x, y),
	h_step(1), v_step(1) {
	width = strlen(bullet_shape);
	shape = new char[width+1];
	strcpy(shape, bullet_shape);
}

void Bullet::move_up() {
	assert(alive);
	hide();
	y = y - v_step;
	if (y >= 0) {
		show();
	} else {
		alive = false;
	}
}
