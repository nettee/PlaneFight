#include <windows.h>

static int sec = 0;

bool tick() {
	static int count = 0;
	Sleep(1);
	if (count == 7) {
		count = 0;
		sec++;
		return true;
	} else {
		count += 1;
		return false;
	}
}

int time() {
	return sec;
}


