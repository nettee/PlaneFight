#include "defs.h"

Key key = {'a', 'd', 'w', 's'};

Screen screen = {31, 50};


