#ifndef DEFS_H_
#define DEFS_H_

struct Screen {
	short height;
	short width;
};

extern Screen screen;

struct Key {
	char left;
	char right;
	char up;
	char down;
};

extern Key key;

#define flat(x, y) (x + y * screen.width)

#endif /* DEFS_H_ */
