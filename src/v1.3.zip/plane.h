#ifndef PLANE_H_
#define PLANE_H_

#include "buffer.h"

extern Buffer buffer;

class Plane {
private:
	int x, y;
	const char *shape;
	const int width;
	const int h_step, v_step;

public:
	Plane();
	~Plane();

public:
	void show();
	void hide();

	void move_left();
	void move_right();
	void move_up();
	void move_down();

	void fire();
};

#endif /* PLANE_H_ */
