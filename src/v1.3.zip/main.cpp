#include <stdio.h>
#include <stdlib.h>

#include <windows.h>
#include <conio.h>

#include "defs.h"
#include "buffer.h"

void init_console();
void do_welcome();
void play_game();

Buffer buffer;

int main()
{
	init_console();

	while (true) {
		do_welcome();

		while (!kbhit());
		char c = getch();

		if (c == 'q') {
			exit(0);
		} else {
			play_game();
		}
	}

    return 0;
}


void do_welcome()
{
	buffer.clear();
	buffer.draw_string("PLANE FIGHT", 7);
	buffer.draw_string("version 1.3", 9);
	buffer.draw_string("Help poor children in Uganda!", 15);
	buffer.display();
}
