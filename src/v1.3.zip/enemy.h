#ifndef ENEMY_H_
#define ENEMY_H_

#include "flyable.h"

struct enemy_info {
	const char *shape;
	const int width;
	const int life;
};

#define NR_ENEMY 2

extern enemy_info enemy_list[];

class Enemy : public Flyable{
private:
	const int h_step, v_step;

public:
	int life;

public:
	Enemy(int x, int y, int type);

	void forward() {
		move_down();
	}

private:
	void move_down();

public:
	bool hit_with_bullet();
	void destroy();
};

#endif /* ENEMY_H_ */
