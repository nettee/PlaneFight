#ifndef ENEMY_POOL_H_
#define ENEMY_POOL_H_

#include <list>

#include "enemy.h"

class EnemyPool {
private:
	std::list<Enemy> enemies;

public:
	void add(int x, int y, int type);
	void forward();
	void update();
};

#endif /* ENEMY_POOL_H_ */
