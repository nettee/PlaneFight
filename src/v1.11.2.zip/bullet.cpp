#include "bullet.h"
#include "pool.h"

#include <cstring>
#include <cassert>

#include "buffer.h"

bullet_info bullet_list[NR_BULLET_TYPE] = {
		{"'"},
		{";"},
};

Bullet::Bullet(int x, int y, int type): Flyable(x, y),
		h_step(1), v_step(1) {
	bullet_info bi = bullet_list[type];
	width = strlen(bi.shape);
	shape = new char[width+1];
	strcpy(shape, bi.shape);

	this->type = type;
}

void Bullet::move_up() {
	assert(alive);
	hide();
	y = y - v_step;
	if (y >= 0) {
		show();
	} else {
		alive = false;
	}
}

void BulletPool::clear() {
	bullets.clear();
}

void BulletPool::add(int x, int y, int type) {
	bullets.push_back(Bullet(x, y, type));
}

void BulletPool::forward() {
	for (list_iter it = bullets.begin(); it != bullets.end(); ++it) {
		if (it->isAlive()) {
			it->forward();
		} else {
			// remove inactive bullets
			it = bullets.erase(it);
		}
	}
}

/* Check if any bullet collides with the object who occupies the area
 * if there exists, erase the bullet
 * return bullet_type, -1 for no bullet
 */
bool BulletPool::check_collision_with_enemy(Enemy *enemy) {
	Area enemy_area = enemy->area();
	bool result = false;
	for (list_iter it = bullets.begin(); it != bullets.end(); ++it) {
		if (it->overlaps(enemy_area)) {
			it->destroy();
			it = bullets.erase(it);
			result = true;
		}
	}
	return result;
}
