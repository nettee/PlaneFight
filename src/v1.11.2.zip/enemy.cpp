#include "enemy.h"
#include "pool.h"

#include <cstring>
#include <cassert>

#include "defs.h"
#include "buffer.h"

void add_score(int incr);

enemy_info enemy_list[NR_ENEMY] = {
		{"=.=", 3, 4, 1},
		{"(-_-)", 5, 9, 2},
		{"=-[o_o]-=", 9, 21, 5},
};

Enemy::Enemy(int x, int y, int type): Flyable(x, y),
		h_step(1), v_step(1) {
	enemy_info ei = enemy_list[type];
	width = ei.width;
	shape = new char[width+1];
	strcpy(shape, ei.shape);
	life = ei.life;
	value = ei.value;
}

void Enemy::move_down() {
	assert(alive);
	hide();
	y = y + v_step;
	if (y < scr_height) {
		show();
	} else {
		alive = false;
	}
}

bool Enemy::check_hit_bullet() {
	return bpool.check_collision_with_enemy(this);
}

void EnemyPool::clear() {
	enemies.clear();
}

void EnemyPool::add(int x, int y, int type) {
	enemies.push_back(Enemy(x, y, type));
}

void EnemyPool::forward() {
	for (list_iter it = enemies.begin(); it != enemies.end(); ++it) {
		if (it->isAlive()) {
			it->forward();
		} else {
			// remove dead enemies
			it = enemies.erase(it);
		}
	}
}

void EnemyPool::check_hit_bullet() {
	for (list_iter it = enemies.begin(); it != enemies.end(); ++it) {
		if (it->check_hit_bullet()) {
			if (it->life > 0) {
				it->life--;
				it->redraw();  // ensure enemy is wholly displayed
			} else {
				it->destroy();
				add_score(it->value);
				it = enemies.erase(it);
			}
		}
	}
}

// check collision with plane
bool EnemyPool::check_collision_with_plane(Area plane_area) {
	bool result = false;
	for (list_iter it = enemies.begin(); it != enemies.end(); ++it) {
		if (it->overlaps(plane_area)) {
			it->destroy();
			add_score(it->value);
			plane.decrease_life();
			it = enemies.erase(it);
			result = true;
		}
	}
	return result;
}
