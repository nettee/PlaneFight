#include <cstdio>
#include <cstdlib>
#include <cctype>
#include <time.h>
#include <windows.h>
#include <conio.h>

#include "defs.h"
#include "buffer.h"
#include "plane.h"
#include "enemy.h"
#include "supply.h"
#include "pool.h"

bool tick();
int second();

extern Buffer buffer;

struct Key {
	char left, right, up, down;
	char pause;
} key = {
		'a', 'd', 'w', 's',
		'p',
};

bool isKey(char ch, char key) {
	return tolower(ch) == tolower(key);
}

static unsigned int score;

void add_score(int incr) {
	if (plane.score_double) {
		score += incr * 2;
	} else {
		score += incr;
	}
}

Plane plane;
BulletPool bpool;
EnemyPool epool;
SupplyPool spool;

void init_game()
{
	plane.init();
	bpool.clear();
	epool.clear();
	spool.clear();

	srand(time(NULL));

	buffer.clear();
	plane.show();
	buffer.display();
	score = 0;
}

void pause() {
	while (true) {
		if (kbhit()) {
			char k = getch();
			if (isKey(k, key.pause)) {
				return;
			}
		}
	}
}

void print_score() {
	char s[20];
	sprintf(s, "Score: %d", score);
	buffer.draw_string(s, 0, 0);
}

void print_plane_status() {
	char s[20];
	sprintf(s, "%c %c x%d",
			(plane.fire_double > 0) ? 'D' : ' ',
			(plane.fire_enhance > 0) ? 'E' : ' ',
			(plane.score_double > 0) ? 2 : 1);
	buffer.draw_string(s, 16, 0);

	for (int i = 0; i < max_life; i++) {
		if (i < plane.life) {
			buffer.draw_character('\3', scr_width-1 - i, 0);
		} else {
			buffer.draw_character(' ', scr_width-1 - i, 0);
		}
	}
}

void print_game_status() {
	print_score();
	print_plane_status();
}

void generate_enemy() {
	int type = rand() % NR_ENEMY;
	enemy_info ei = enemy_list[type];
	int x = rand() % (scr_width - ei.width + 1);
	epool.add(x, 0, type);
}

bool generate_supply() {
	int type = rand() % NR_SUPPLY_TYPE;
	supply_info si = supply_list[type];
	int x = rand() % (scr_width - strlen(si.shape) + 1);
	spool.add(x, 0, type);
	return true;
}

int play_game()
{
	init_game();

	while (true) {

		// watch keyboard hit
		if (kbhit()) {
			char k = getch();
			if (isKey(k, key.left)) {
				plane.move_left();
			} else if (isKey(k, key.right)) {
				plane.move_right();
			} else if (isKey(k, key.up)) {
				plane.move_up();
			} else if (isKey(k, key.down)) {
				plane.move_down();
			} else if (isKey(k, key.pause)) {
				pause();
			}
		}


		if (tick()) {

			// bullets go forward
			bpool.forward();
			epool.check_hit_bullet();

			// enemy go forward
			if (second() % 2 == 0) {
				epool.forward();
				epool.check_hit_bullet();
			}

			if (second() % 2 == 0) {
				spool.forward();
			}

			spool.check_collision_with_plane(plane.area());
			epool.check_collision_with_plane(plane.area());
			plane.update();
			if (plane.isDead()) {
				return score;
			}

			if (second() % 43 == 0) {
				generate_supply();
			}
			else if (second() % 3 == 0) {
				generate_enemy();
			}

			plane.fire();
		}


		plane.show();  // ensure the plane is always visual
		print_game_status();
		buffer.display();

	}
}
